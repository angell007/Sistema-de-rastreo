<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Accion;
use Faker\Generator as Faker;

$factory->define(Accion::class, function (Faker $faker) {
    return [
        //
    ];
});
