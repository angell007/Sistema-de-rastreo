<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Clausula;
use Faker\Generator as Faker;

$factory->define(Clausula::class, function (Faker $faker) {
    return [
        //
    ];
});
