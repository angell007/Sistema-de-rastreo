<div class="text-lg-right text-nowrap">
    <a class="btn btn-success edit-clausula" href="javascript:void(0)" onclick="editarClausula({{$id}})"
        data-toggle="tooltip" title="Editar">
        <i class="fa fa-edit"></i>
    </a>

    <a class="btn btn-danger delete-clausula" href="javascript:void(0)" onclick="eliminarClausula({{$id}})"
        data-toggle="tooltip" title="Eliminar">
        <i class="fa fa-fw fa-trash"></i>
    </a>
    
</div>