<div class="text-lg-right text-nowrap">
    
        <a class="btn btn-xs btn-dark" href="{{route('orders.show', $id)}}" title="Historial">
            <i class="fa fa-fw fa-calendar"></i>
        </a>
    
        <a class="btn btn-xs btn-warning" href="{{route('orders.printOrder', $id)}}" title="Print">
            <i class="fa fa-fw fa-print"></i>
        </a>
    
    </div>