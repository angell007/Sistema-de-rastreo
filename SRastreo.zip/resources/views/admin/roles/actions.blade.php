<div class="text-lg-right text-nowrap">

    <a class="btn btn-icon btn-danger delete-rol" href="javascript:void(0)" onclick="eliminarRol({{$id}})"
        title="Eliminar">
        <i class="fa fa-fw fa-trash"></i>
    </a>

</div>