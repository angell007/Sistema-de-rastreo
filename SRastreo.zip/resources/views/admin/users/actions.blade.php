<div class="text-lg-right text-nowrap">

    <a class="btn btn-primary" href="{{route('users.show', $id)}}">
        <i class="fa fa-fw fa-eye"></i>
    </a>

</div>