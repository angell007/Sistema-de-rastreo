<div class="text-lg-right text-nowrap">
    <a class="btn btn-success edit-accion" href="javascript:void(0)" onclick="editarAccion({{$id}})"
        data-toggle="tooltip" title="Editar">
        <i class="fa fa-edit"></i>
    </a>

    <a class="btn btn-danger delete-accion" href="javascript:void(0)" onclick="eliminarAccion({{$id}})"
        data-toggle="tooltip" title="Eliminar">
        <i class="fa fa-fw fa-trash"></i>
    </a>

</div>
